<?php
return[


'kadro' => [
    'Yönetim Kurulu' => 'Yönetim Kurulu',
    'Denetim Kurulu' => 'Denetim Kurulu',
    'İdari Kadro' =>'İdari Kadro',

],
    'kategori' => [


        '1'=>'Milli Katılım',
        '2'=>'İnfo Stand',
        '3'=>'Ticaret Heyeti',
        '4'=>'Sanal Ticaret Heyeti ',
        '5'=>'Alım Heyeti',
        '6'=>'URGE',
        '7'=>'Çalıştay ',
        '8'=>'İhracat Ödül Töreni',
        '9'=>'Yarışma',
        '10'=>'ARGE',
        '11'=>'Diğer',
    ]

];
