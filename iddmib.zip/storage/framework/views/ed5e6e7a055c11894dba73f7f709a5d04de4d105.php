<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'turkishMetals')); ?></title>


    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <!-- googlefonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- swiperjs -->
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">

    <link rel="stylesheet" href="<?php echo e(asset('assets/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/responsive.css')); ?>" />
    <?php echo toastr_css(); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>


</head>

<body>
    <header class="header bg-white">
        <div class="container">
            <nav class="navbar navbar-expand-lg bg-white navbar-light">
                <a href="<?php echo e(route('home')); ?>" class="navbar-brand"><img  src="<?php echo e(asset('assets/images/logo.svg')); ?>" alt="..." /></a>
                <button class="navbar-toggler" data-toggle="collapse" data-target="#mynav"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="mynav">
                     <ul class="navbar-nav ml-auto">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">Kurumsal</a>
                            <div class="dropdown-menu rounded-0">
                                <a href="<?php echo e(route('hakkimizda')); ?>" class="dropdown-item">Hakkımızda</a>
                                <a href="<?php echo e(route('yonetimkurulu')); ?>" class="dropdown-item">Yönetim ve Denetim Kurulu</a>
                                <a href="<?php echo e(route('idarikadro')); ?>" class="dropdown-item">İdari Kadro</a>


                            </div>
                        </li>
                         <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">İhracat</a>
                            <div class="dropdown-menu rounded-0">
                                <a href="<?php echo e(route('ihracatrota')); ?>" class="dropdown-item">İhracat Radarı</a>
                                <a href="<?php echo e(route('devletdestek')); ?>" class="dropdown-item">Devlet Destekleri</a>
                                <a href="<?php echo e(route('ihracatrapor')); ?>" class="dropdown-item">İhracat Raporları</a>

                            </div>
                        </li>
                         <li class="nav-item dropdown">
                             <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">Sektörler</a>
                             <div class="dropdown-menu rounded-0">
                                 <?php $__currentLoopData = $sektor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <a href="<?php echo e(route('sektordetail',$value->id)); ?>" class="dropdown-item"><?php echo e($value->baslik); ?></a>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </div>
                         </li>
                         <li class="nav-item dropdown">
                             <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">Faaliyetler</a>
                             <div class="dropdown-menu rounded-0">
                                 <a href="<?php echo e(route('etkinlik')); ?>" class="dropdown-item">Etkinlik Takvimi</a>
                                 <?php $__currentLoopData = $faaliyet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <a href="<?php echo e(route('faaliyet',$value)); ?>" class="dropdown-item"><?php echo e($value->baslik); ?></a>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <a href="<?php echo e(route('inovasyon',9)); ?>" class="dropdown-item">İhracat Başarı Ödülleri</a>

                             </div>
                         </li>
                         <li class="nav-item dropdown">
                             <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">İnovasyon</a>
                             <div class="dropdown-menu rounded-0">
                                 <?php $__currentLoopData = $inovasyon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <a href="<?php echo e(route('inovasyon',$value)); ?>" class="dropdown-item"><?php echo e($value->baslik); ?></a>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                             </div>
                         </li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('uyelik')); ?>">Üyelik</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('iletisim')); ?>">İletişim</a></li>
                    </ul>
                </div>
            </nav>
        </div>

        <div class="bg-gray p-2 text-light">
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-12 col-md-auto">
                        İstanbul Demir ve Demir Dışı Metaller İhracatçıları Birliği
                    </div>
                    <div class="col-12 col-md-auto text-center text-md-right">
                        <ul class="list-inline m-0">
                            <li class="list-inline-item"><a class="<?php if( Config::get('app.locale') == 'tr'): ?> text-light   <?php else: ?> text-secondary   <?php endif; ?>  text-decoration-none" href="<?php echo e(route('setlocale','tr')); ?>">Türkçe</a></li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- social start -->
    <div class="left-social">
        <ul class="list-unstyled mb-0">
            <li class="mb-2"><a href="https://twitter.com/iddmibtr"><img src="<?php echo e(asset('assets/images/twitter.svg')); ?>" alt="..." /></a></li>
            <li class="mb-2"><a href="https://www.facebook.com/iddmib/"><img src="<?php echo e(asset('assets/images/facebook.svg')); ?>" alt="..." /></a></li>
            <li class="mb-2"><a href="https://www.instagram.com/iddmib/"><img src="<?php echo e(asset('assets/images/instagram.svg')); ?>" alt="..." /></a></li>
            <li class="mb-2"><a href="https://www.linkedin.com/company/iddmib/"><img src="<?php echo e(asset('assets/images/linked.svg')); ?>" alt="..." /></a></li>
            <li><a href="https://www.youtube.com/channel/UCtm4OO9pVLzCXUjKk75cK8A"><img src="<?php echo e(asset('assets/images/youtube.svg')); ?>" alt="..." /></a></li>
        </ul>
    </div>
    <!-- social end -->
    <?php echo e($slot); ?>



    <!-- Main Footer -->
    <footer class="footer">
        <div class="footer-top border-top border-bottom py-5 position-relative">
            <a class="toTop" href="javascript:void(0);"><img src="<?php echo e(asset('assets/images/arrow-up.svg')); ?>" alt="..." /></a>
            <div class="container">
                <div class="row text-center">
                    <div class="col-12">
                        <a href="<?php echo e(route('hakkimizda')); ?>" class="btn btn-outline-secondary mb-2 mr-2">Hakkımızda</a>
                        <a href="<?php echo e(route('yonetimkurulu')); ?>" class="btn btn-outline-secondary mb-2 mr-2">Yönetim ve Denetim Kurulu</a>
                        <a href="<?php echo e(route('idarikadro')); ?>" class="btn btn-outline-secondary mb-2 mr-2">İdari Kadro</a>


                        <a href="<?php echo e(route('uyelik')); ?>" class="btn btn-outline-secondary mb-2 mr-2">Üyelik</a> <br />
                        <a href="<?php echo e(route('ihracatrota')); ?>" class="btn btn-outline-secondary mb-2 mr-2">İhracat Radarı</a>
                        <a href="<?php echo e(route('devletdestek')); ?>" class="btn btn-outline-secondary mb-2 mr-2">Devlet Destekleri</a>
                        <a href="<?php echo e(route('ihracatrapor')); ?>" class="btn btn-outline-secondary mb-2 mr-2">İhracat Raporları</a>

                        <?php $__currentLoopData = $sektor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('sektordetail',$value->id)); ?>" class="btn btn-outline-secondary mb-2 mr-2"><?php echo e($value->baslik); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <br />
                        <a href="<?php echo e(route('etkinlik')); ?>" class="btn btn-outline-secondary mb-2 mr-2">Etkinlik Takvimi</a>
                        <?php $__currentLoopData = $faaliyet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('faaliyet',$value)); ?>"  class="btn btn-outline-secondary mb-2 mr-2"><?php echo e($value->baslik); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $inovasyon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('inovasyon',$value)); ?>"  class="btn btn-outline-secondary mb-2 mr-2"><?php echo e($value->baslik); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('iletisim')); ?>" class="btn btn-outline-secondary mb-2 mr-2">İletişim</a>


                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom py-4 bg-white">
            <div class="container">
                <div class="row">
                    <div class="col-md-9">
                        <ul class="social list-inline">
                            <li class="list-inline-item"><a href="https://twitter.com/iddmibtr"><img src="<?php echo e(asset('assets/images/twitter.svg')); ?>" alt="..." /></a></li>
                            <li class="list-inline-item"><a href="https://www.facebook.com/iddmib/"><img src="<?php echo e(asset('assets/images/facebook.svg')); ?>" alt="..." /></a></li>
                            <li class="list-inline-item"><a href="https://www.instagram.com/iddmib/"><img src="<?php echo e(asset('assets/images/instagram.svg')); ?>" alt="..." /></a></li>
                            <li class="list-inline-item"><a href="https://www.linkedin.com/company/iddmib/"><img src="<?php echo e(asset('assets/images/linked.svg')); ?>" alt="..." /></a></li>
                            <li class="list-inline-item"><a href="https://www.youtube.com/channel/UCtm4OO9pVLzCXUjKk75cK8A"><img src="<?php echo e(asset('assets/images/youtube.svg')); ?>" alt="..." /></a></li>
                        </ul>
                        <ul class="list-inline list-dots">
                            <li class="list-inline-item"><a class="text-dark" href="#">Copyright © 2020,</a></li>
                            <li class="list-inline-item"><a class="text-dark" href="#">İDDMİB - Her hakkı saklıdır</a></li>
                            <li class="list-inline-item"><a class="text-dark" href="#">Gizlilik  </a></li>
                            <li class="list-inline-item"><a class="text-dark" href="#">Şartlar   </a></li>
                            <li class="list-inline-item"><a class="text-dark" href="#">Site haritası   </a></li>
                        </ul>
                    </div>
                    <div class="col-md-3">
                        <h1 class="display-3"><a class="text-dark text-decoration-none" href="#"><img class="img-fluid" src="<?php echo e(asset('assets/images/footerLogo.svg')); ?>" alt="..." /></a></h1>
                    </div>
                </div>
            </div>
        </div>
    </footer>
<!-- REQUIRED SCRIPTS -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
<!-- swiperjs -->
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

    <script src="<?php echo e(asset('assets/mixitup.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/main.js')); ?>"></script>
    <?php echo toastr_js(); ?>
    <?php echo app('toastr')->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\iddmib\resources\views/layouts/front-app.blade.php ENDPATH**/ ?>