 <?php if (isset($component)) { $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FrontApp::class, []); ?>
<?php $component->withName('front-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>


    <main class="detail">
        <div class="position-relative mb-4">
            <img  src="<?php echo e(asset('assets/images/aboutBg.png')); ?>" alt="" class="img-fluid" />
            <div class="container">
                <div class="bread"><h1 class="text-white">İhracat Raporları</h1></div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-wrap">
                    <h4>Sektörlerimize ait güncel ihracat raporlarını keşfedin!</h4>


                </div>
            </div>
        </div>
        <hr class="mb-5" />

        <div class="container mb-5">
            <div class="row">
                <div class="col-12">
                    <div class="position-relative">
                        <img src="<?php echo e(asset('assets/images/raporbg.svg')); ?>" alt="..." class="img-fluid"/>
                        <a target="_blank" href="<?php echo e(asset("storage/files/ihracat_files/$ir_first->pdf")); ?>"
                           class="text-decoration-none text-light d-flex justify-content-between bg-red position-absolute p-3 text-light w-100"
                           style="bottom:0;">
                            <div class="d-flex  align-items-center">
                                <img src="<?php echo e(asset('assets/images/doc-light.svg')); ?>" class="mr-3" width="46" alt="..."/>
                                <h4 class="m-0"> <?php echo e($ir_first->baslik); ?>

                                </h4>
                            </div>
                            <img src="<?php echo e(asset('assets/images/arrow-right-light.svg')); ?>" width="46" alt="..."/>
                        </a>
                    </div>
                </div>
            </div>
        </div>































    </main>


 <?php if (isset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0)): ?>
<?php $component = $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0; ?>
<?php unset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\wamp64\www\iddmib\resources\views/frontend/ihracatrapor.blade.php ENDPATH**/ ?>