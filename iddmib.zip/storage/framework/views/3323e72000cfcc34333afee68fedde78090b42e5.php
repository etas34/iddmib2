 <?php if (isset($component)) { $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FrontApp::class, []); ?>
<?php $component->withName('front-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>


    <main class="detail">
        <div class="position-relative mb-4">
            <img src="<?php echo e(asset('assets/images/aboutBg.png')); ?>" alt="" class="img-fluid" />
            <div class="container">
                <div class="bread"><h1 class="text-white">Haberler ve Duyurular</h1></div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-wrap">
                    <h4>Sektörel gelişmeler hakkında güncel haber ve duyuruları keşfedin!</h4>





                </div>
            </div>
        </div>
        <hr class="mb-5" />


                    <div class="sectors mb-5">
                        <div class="container">
                            <div class="row mb-4">
                                <div class="col-12">
                                    <h3 class="text-danger font-weight-bold">Haberler</h3>
                                    <h5>Quisque velit nisi, pretium ut lacinia in, elementum id enim</h5>
                                </div>
                            </div>
                            <div class="row row-cols-sm-2">
                                <?php $__currentLoopData = $haber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-12 mb-3 mb-md-5">
                                        <a href="<?php echo e(route('haber',$value)); ?>"><img class="img-fluid mb-3" src="<?php echo e(asset("storage/images/haber_images/$value->ana_resim")); ?>" alt="..." /></a>
                                        <h5><a class="d-block text-secondary text-decoration-none small " href="<?php echo e(route('haber',$value)); ?>"><?php echo e($value->tarih); ?></a></h5>
                                        <h4><a href="<?php echo e(route('haber',$value)); ?>" class="text-dark font-weight-bold text-decoration-none" href="#"><?php echo e($value->baslik); ?></a></h4>
                                        <h5><a class="text-secondary text-decoration-none" href="<?php echo e(route('haber',$value)); ?>"><?php echo e($value->alt_baslik); ?></a></h5>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </div>
                        </div>
                    </div>


    </main>

 <?php if (isset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0)): ?>
<?php $component = $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0; ?>
<?php unset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\wamp64\www\iddmib\resources\views/frontend/haberler.blade.php ENDPATH**/ ?>