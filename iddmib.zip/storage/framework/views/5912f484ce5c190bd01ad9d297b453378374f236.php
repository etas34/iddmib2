 <?php if (isset($component)) { $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FrontApp::class, []); ?>
<?php $component->withName('front-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>


    <main class="detail">
        <div class="position-relative mb-4">
            <img src="<?php echo e(asset('assets/images/aboutBg.png')); ?>" alt="" class="img-fluid" />
            <div class="container">
                <div class="bread"><h1 class="text-white"><?php echo e($haber->baslik); ?></h1></div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-wrap">
                    <h4><?php echo e($haber->alt_baslik); ?></h4>





                </div>
            </div>
        </div>
        <hr class="mb-5" />

        <div class="container mb-5">
            <div class="row">
                <div class="col-12">
                    <img src="<?php echo e(asset("storage/images/haber_images/$haber->detay_resim")); ?>"   width="100%"  alt="..." class="img-fluid mb-4 text-center" />


                    <h3 class="text-danger font-weight-bold"><?php echo e($haber->metin_altbaslik); ?></h3>
                    <?php echo $haber->aciklama; ?>



                </div>
            </div>
        </div>

    </main>

 <?php if (isset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0)): ?>
<?php $component = $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0; ?>
<?php unset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\wamp64\www\iddmib\resources\views/frontend/haber.blade.php ENDPATH**/ ?>