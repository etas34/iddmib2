 <?php if (isset($component)) { $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FrontApp::class, []); ?>
<?php $component->withName('front-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>


    <main class="detail">
        <div class="position-relative mb-4">
            <img src="<?php echo e(asset('assets/images/aboutBg.png')); ?>"  alt="" class="img-fluid" />
            <div class="container">
                <div class="bread"><h1 class="text-white">Etkinlikler</h1></div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-wrap">
                    <h4>Güncel etkinliklerimizi keşfedin!</h4>





                </div>
            </div>
        </div>
        <hr class="mb-5" />

        <div class="container mb-5">
            <div class="row text-center">
                <div class="col-12">
                    <button class="btn btn-danger mb-2 mr-2" data-mixitup-control data-filter="all">Tüm Etkinlikler</button>
                    <br />
                    <?php $__currentLoopData = $sektor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button class="btn btn-outline-secondary mb-2 mr-2" data-mixitup-control data-filter=".sektor_<?php echo e($value->id); ?>">
                        <?php echo e($value->baslik); ?></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <br />
                    <?php $__currentLoopData = config('constants.kategori'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button class="btn btn-outline-secondary mb-2 mr-2" data-mixitup-control data-filter=".kategori_<?php echo e($key); ?>">
                            <?php echo e($value); ?></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






                </div>
            </div>
        </div>

        <div class="container mb-5">
            <div class="mixitup row row-cols-sm-2 row-cols-sm-3">
                <?php $__currentLoopData = $etkinlik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 mb-3 mix <?php echo e('sektor_'.$value->sektor_id); ?> <?php echo e('kategori_'.$value->kategori_id); ?>">
                    <div class="card rounded-lg">
                        <div class="card-header text-danger bg-transparent"><?php echo e(\DateTime::createFromFormat("Y-m-d", $value->tarih)->format("d/m/Y")); ?>-<?php echo e(\DateTime::createFromFormat("Y-m-d", $value->tarih2)->format("d/m/Y")); ?></div>
                        <div class="card-body">
                            <h4><?php echo e($value->baslik); ?>

                                <br>
                                <?php echo e($value->altbaslik); ?>

                            </h4>
                        </div>
                        <div class="card-footer bg-transparent border-top-0 text-secondary d-flex justify-content-between">
                            <span> <?php echo e(\App\Models\Sektor::find($value->sektor_id)->baslik); ?></span>
                            <span><?php echo e(config('constants.kategori.'.$value->kategori_id)); ?></span>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>

    </main>


 <?php if (isset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0)): ?>
<?php $component = $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0; ?>
<?php unset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\wamp64\www\iddmib\resources\views/frontend/etkinlik.blade.php ENDPATH**/ ?>