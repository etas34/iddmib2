 <?php if (isset($component)) { $__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminApp::class, []); ?>
<?php $component->withName('admin-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('styles'); ?>


    <?php $__env->stopPush(); ?>


    <div class="row">
        <!-- left column -->
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">İhracat Raporları</h3>
                 <a href="<?php echo e(route('admin.ihracat.create')); ?>" class="btn btn-primary active" style="float: right !important;">Yeni Rapor Ekle</a>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>Dosya</th>
                            <th>Sektör</th>
                            <th>Rapor Adı</th>
                            <th>Düzenle</th>
                            <th>Sil</th>


                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $ihracat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td><a target="_blank" href="<?php echo e(asset("storage/files/ihracat_files/$value->pdf")); ?>"> Rapor PDF <i class="nav-icon fa fa-file-pdf"></i></a></td>
                            <td><?php echo e(\App\Models\Sektor::find($value->sektor_id)->baslik); ?></td>
                            <td><?php echo e($value->baslik); ?></td>



                            <td><a href="<?php echo e(route('admin.ihracat.edit',$value)); ?>"><span class="badge bg-warning p-2">Düzenle</span></a></td>
                            <td><a href="<?php echo e(route('admin.ihracat.destroy',$value)); ?>" onclick="return confirm('Kaydı silmek istediğinize emin misiniz?')"><span class="badge bg-danger p-2">Sil</span></a></td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
        </div>
    </div>


    <?php $__env->startPush('scripts'); ?>


    <?php $__env->stopPush(); ?>
 <?php if (isset($__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7)): ?>
<?php $component = $__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7; ?>
<?php unset($__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php /**PATH C:\wamp64\www\iddmib\resources\views/admin/ihracat/index.blade.php ENDPATH**/ ?>