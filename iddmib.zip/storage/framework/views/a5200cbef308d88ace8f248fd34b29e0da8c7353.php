 <?php if (isset($component)) { $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FrontApp::class, []); ?>
<?php $component->withName('front-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <!-- hero start -->
    <div style="background-image: url(<?php echo e(asset("storage/images/slider_images/$slider->image")); ?>) !important" class="hero text-light mb-5">
        <div class="container" style="margin-top: 15px;">
            <div class="row mb-5">
                <div class="col-sm-8">
                    <h1><?php echo e($slider->baslik); ?></h1>
                    <h2 class="mb-3"><?php echo e($slider->alt_baslik); ?>

                    </h2>

                </div>
            </div>
        </div>
    </div>
    <!-- hero end -->

    <!-- notice start -->
    <div class="notice mb-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="text-danger font-weight-bold">İDDMİB'ten Duyurular</h3>
                    <h5>Birliğimiz hakkında güncel duyuruları keşfedin!</h5>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="swiper-container">
                        <div class="swiper-wrapper">
                            <?php $__currentLoopData = $duyuru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="swiper-slide">
                                        <a href="<?php echo e($value->link); ?>">
                                            <img class="img-fluid" src="<?php echo e(asset("storage/images/duyuru_images/$value->image")); ?>" alt="..." />
                                        </a>


                                    </div>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                    <div role="button" class="notice-left"><img src="<?php echo e(asset('assets/images/arrow-left-red.svg')); ?>" alt="..." /></div>
                    <div role="button" class="notice-right"><img src="<?php echo e(asset('assets/images/arrow-right-red.svg')); ?>" alt="..." /></div>
                </div>
            </div>

        </div>
    </div>
    <!-- notice end -->
    <hr class="mb-5" />

    <!-- message start -->
    <div class="message mb-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="text-danger font-weight-bold">Başkan'ın Mesajı</h3>
                  <h5><?php echo $baskan->alt_baslik; ?></h5>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <a href="<?php echo e(route('baskanmesaj')); ?>">  <img src="<?php echo e(asset("storage/images/baskan_images/$baskan->image")); ?>" alt="..." class="img-fluid" /></a>
                </div>
            </div>
        </div>
    </div>
    <!-- message end -->

    <!-- apply start -->
    <div class="apply mb-5 text-light">
        <div class="bg-red py-3">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-sm-8">
                        İhracat dünyası hakkında bilgi almak için,
                    </div>
                    <div class="col-sm-4">
                        <a href="<?php echo e(route('iletisim')); ?>" class="btn btn-light font-weight-bold">İLETİŞİME GEÇİN </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- apply end -->

    <!-- news start -->
    <div class="news mb-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="text-danger font-weight-bold">Haberler ve Duyurular</h3>
                    <h5>Sektörel gelişmeler hakkında güncel haber ve duyuruları keşfedin!</h5>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-12">
                    <div class="swiper-container">
                        <div class="swiper-wrapper">

                        <?php $__currentLoopData = $haber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide">
                                <a href="<?php echo e(route('haber',$value)); ?>"><img class="img-fluid mb-3" src="<?php echo e(asset("storage/images/haber_images/$value->ana_resim")); ?>" alt="..." /></a>
                               <a class="" style="color: #6c757d " href="<?php echo e(route('haber',$value)); ?>"><?php echo e($value->tarih); ?></a>
                                <h5><a class="text-dark text-decoration-none" href="<?php echo e(route('haber',$value)); ?>"><?php echo e($value->baslik); ?></a></h5>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>

                    </div>
                    <div role="button" class="news-left"><img src="<?php echo e(asset('assets/images/arrow-left-red.svg')); ?>" alt="..." /></div>
                    <div role="button" class="news-right"><img src="<?php echo e(asset('assets/images/arrow-right-red.svg')); ?>" alt="..." /></div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <a class="text-danger" href="<?php echo e(route('haberler')); ?>">Tüm haberleri göster</a>
                </div>
            </div>
        </div>
    </div>
    <!-- news end -->

    <!-- numbers start -->
    <div class="numbers text-light py-5 mb-5">
        <div class="container">
            <div class="row text-center text-sm-left">
                <div class="col-12 col-sm-4 d-flex flex-column mb-3 mb-sm-0">
                    <h2>Demir ve Demir Dışı Metaller Sektör İhracatı</h2>
                    <div class="mt-auto">
                        <p>Son Güncelleme Tarihi</p>
                        <p><?php echo e($ihracatRakam->guncelleme_tarih ?? ''); ?></p>
                    </div>
                </div>
                <div class="col-12 col-sm-4 mb-3 mb-sm-0">
                    <h2>Son Ay</h2>
                    <p><?php echo e($ihracatRakam->o_birinci ?? ''); ?></p>
                    <h1 class="display-3 font-weight-bold"><?php echo e($ihracatRakam->o_ikinci ?? ''); ?></h1>
                    <h4><?php echo e($ihracatRakam->o_ucuncu ?? ''); ?></h4>
                </div>
                <div class="col-12 col-sm-4 mb-3 mb-sm-0">
                    <h2>Son 12 Ay</h2>
                    <p><?php echo e($ihracatRakam->s_birinci ?? ''); ?></p>
                    <h1 class="display-3 font-weight-bold"><?php echo e($ihracatRakam->s_ikinci ?? ''); ?></h1>
                    <h4><?php echo e($ihracatRakam->s_ucuncu ?? ''); ?></h4>
                </div>
            </div>
        </div>
    </div>
    <!-- numbers end -->

    <!-- sectors start -->
    <div class="sectors mb-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="text-danger font-weight-bold">Sektörler</h3>
                    <h5>Sektörlerimizi keşfedin!</h5>
                </div>
            </div>
            <div class="row row-cols-sm-2 row-cols-md-3 text-center text-sm-left">
                <?php $__currentLoopData = $sektor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 mb-3">
                        <a href="<?php echo e(route('sektordetail',$value)); ?>"><img class="img-fluid mb-3" src="<?php echo e(asset("storage/images/sektor_images/$value->ana_resim")); ?>" alt="..." /></a>
                        <h4><a href="<?php echo e(route('sektordetail',$value)); ?>" class="text-dark font-weight-bold text-decoration-none" href="#"><?php echo e($value->baslik); ?></a></h4>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>












































            </div>
        </div>
    </div>
    <!-- sectors end -->
    <hr class="mb-5" />

    <!-- reports start -->
    <div class="reports mb-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="text-danger font-weight-bold">İhracat Raporları</h3>
                    <h5>Sektörlerimize ait güncel ihracat raporlarını keşfedin!</h5>
                </div>
            </div>


            <div class="row row-cols-sm-2 row-cols-md-3">
                <?php $__currentLoopData = $ihracat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 mb-3">
                    <a target="_blank" href="<?php echo e(asset("storage/files/ihracat_files/$value->pdf")); ?>" class="card p-3 text-decoration-none rounded-lg">
                        <h3 class="text-dark text-decoration-none"><?php echo e(\App\Models\Sektor::find($value->sektor_id)->baslik); ?></h3>
                        <h5 class="text-secondary text-decoration-none"><?php echo e($value->baslik); ?> <br /> İhracat Raporu</h5>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </div>

            </div>
        </div>
    </div>

    <!-- reports end -->
    <hr class="mb-5" />

    <!-- service start -->
    <div class="service mb-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="text-danger font-weight-bold">Faaliyetler</h3>
                    <h5>Güncel faaliyetlerimizi keşfedin!</h5>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-12">
                    <div class="swiper-container">
                        <div class="swiper-wrapper">

                            <?php $__currentLoopData = $faliyet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="swiper-slide">
                                <a href="<?php echo e(route('faaliyet',$value)); ?>"><img class="img-fluid mb-3" src="<?php echo e(asset("storage/images/faliyet_images/$value->ana_resim")); ?>" alt="..." /></a>
                                <h5 class="text-secondary"><a class="text-dark" href="<?php echo e(route('faaliyet',$value)); ?>"><?php echo e($value->baslik); ?></a></h5>
                                <h6><span class="text-secondary text-decoration-none"><?php echo e($value->alt_baslik); ?></span></h6>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </div>

                    </div>
                    <div role="button" class="service-left"><img src="<?php echo e(asset('assets/images/arrow-left-red.svg')); ?>" alt="..." /></div>
                    <div role="button" class="service-right"><img src="<?php echo e(asset('assets/images/arrow-right-red.svg')); ?>" alt="..." /></div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <a class="text-danger" href="#">Tüm faaliyetleri göster</a>
                </div>
            </div>
        </div>
    </div>
    <!-- service end -->

    <hr  class="mb-5"/>

    <!-- threeslide start -->
    <div class="threeslide mb-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="text-danger font-weight-bold">Etkinlik Takvimi</h3>
                    <h5>Güncel etkinliklerimizi keşfedin!</h5>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-12">
                    <div class="swiper-container">
                        <div class="swiper-wrapper">

                        <?php $__currentLoopData = $etkinlik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <div class="card">
                                        <div class="card-header text-danger bg-transparent"><?php echo e(\DateTime::createFromFormat("Y-m-d", $value->tarih)->format("d/m/Y")); ?>-<?php echo e(\DateTime::createFromFormat("Y-m-d", $value->tarih2)->format("d/m/Y")); ?></div>
                                        <div class="card-body">
                                            <h5><?php echo e($value->baslik); ?></h5>
                                        </div>
                                        <div class="card-footer bg-transparent border-top-0">
                                            <?php echo e($value->alt_baslik); ?>

                                        </div>
                                        <div class="card-footer bg-transparent border-top-0 text-secondary d-flex justify-content-between">
                                            <span><?php echo e(\App\Models\Sektor::find($value->sektor_id)->baslik); ?></span>
                                            <span><?php echo e(config('constants.kategori.'.$value->kategori_id)); ?></span>
                                        </div>
                                    </div>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                    </div>
                    <div role="button" class="three-left"><img src="<?php echo e(asset('assets/images/arrow-left-red.svg')); ?>" alt="..." /></div>
                    <div role="button" class="three-right"><img src="<?php echo e(asset('assets/images/arrow-right-red.svg')); ?>" alt="..." /></div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <a class="text-danger" href="<?php echo e(route('etkinlik')); ?>">Tüm etkinlikleri göster</a>
                </div>
            </div>
        </div>
    </div>
    <!-- threeslide end -->

    <hr class="mb-5" />

    <!-- innovation start -->
    <div class="innovation mb-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="text-danger font-weight-bold">İnovasyon</h3>
                    <h5>Güncel inovasyon projelerimizi keşfedin!</h5>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-12">
                    <div class="swiper-container">
                        <div class="swiper-wrapper">
                            <?php $__currentLoopData = $inovasyon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <a href="<?php echo e(route('inovasyon',$value)); ?>"><img class="img-fluid mb-3 d-block mx-auto" src="<?php echo e(asset("storage/images/inovasyon_images/$value->ana_resim")); ?>" alt="..." /></a>
                                    <h5 class="text-secondary"><a class="text-dark" href="<?php echo e(route('inovasyon',$value)); ?>"><?php echo e($value->baslik); ?></a></h5>
                                    <h6><a class="text-secondary text-decoration-none" href="<?php echo e(route('inovasyon',$value)); ?>"><?php echo e($value->alt_baslik); ?></a></h6>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </div>

                    </div>
                    <div role="button" class="innovation-left"><img src="<?php echo e(asset('assets/images/arrow-left-red.svg')); ?>" alt="..." /></div>
                    <div role="button" class="innovation-right"><img src="<?php echo e(asset('assets/images/arrow-right-red.svg')); ?>" alt="..." /></div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <a class="text-danger" href="#">Tüm inovasyonları göster</a>
                </div>
            </div>
        </div>
    </div>
    <!-- innovation end -->

    <hr class="mb-5" />

























    <!-- contact start -->
    <div class="contact mb-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="text-danger font-weight-bold">İletişim</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-sm-6">
                    <img src="<?php echo e(asset('assets/images/contact.svg')); ?>" alt="..." class="img-fluid" />
                </div>
                <div class="col-12 col-sm-6">
                    <h5>İstanbul Demir ve Demir Dışı Metaller İhracatçıları Birliği</h5>
                    <p>Sanayi Cad. No:3, Dış Ticaret Kompleksi
                        A Blok, Çobançeşme Mevkii 34196
                        Bahçelievler / İSTANBUL</p>
                    <p>
                        +90 (212) 454 00 00 (Pbx) <br />
                        iddmib@immib.org.tr
                    </p>
                    <a class="text-danger" href="#">Adrese Git</a>
                </div>
            </div>
        </div>
    </div>
    <!-- contact end -->

    <?php $__env->startPush('scripts'); ?>
        <script>




            
            
        </script>


    <?php $__env->stopPush(); ?>
 <?php if (isset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0)): ?>
<?php $component = $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0; ?>
<?php unset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php /**PATH C:\wamp64\www\iddmib\resources\views/index.blade.php ENDPATH**/ ?>