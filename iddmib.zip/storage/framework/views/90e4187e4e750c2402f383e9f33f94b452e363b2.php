 <?php if (isset($component)) { $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FrontApp::class, []); ?>
<?php $component->withName('front-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>



    <main class="detail">
        <div class="position-relative mb-4">
            <img  src="<?php echo e(asset('assets/images/aboutBg.png')); ?>" alt="" class="img-fluid" />
            <div class="container">
                <div class="bread"><h1 class="text-white">Raporlar</h1></div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-wrap">
                    <h4>Rum intio veribus core adis exerum, vel el mollabo...</h4>


                </div>
            </div>
        </div>
        <hr class="mb-5" />

        <div class="container mb-5">
            <div class="row">
                <div class="col-12">
                    <div class="position-relative">
                        <img  src="<?php echo e(asset('assets/images/raporbg.svg')); ?>" alt="..." class="img-fluid" />
                        <a href="#" class="text-decoration-none text-light d-flex justify-content-between bg-red position-absolute p-3 text-light w-100" style="bottom:0;">
                            <div class="d-flex  align-items-center">
                                <img  src="<?php echo e(asset('assets/images/doc-light.svg')); ?>" class="mr-3" width="46" alt="..." />
                                <h4 class="m-0">2020 <br />
                                    Faliyet Raporu
                                </h4>
                            </div>
                            <img  src="<?php echo e(asset('assets/images/arrow-right-light.svg')); ?>" width="46" alt="..." />
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <hr class="mb-5" />

        <div class="container mb-5">
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="text-danger font-weight-bold">Geçmiş Dönem Raporları</h3>
                </div>
            </div>
            <div class="row">

                <div class="col-12 mb-3">
                    <a href="#" class="text-dark text-decoration-none d-flex justify-content-between align-items-center border bg-transparent py-2 px-3 rounded-lg">
                        <h5 class="mb-0">2019 Yıllık Raporu</h5>
                        <img  src="<?php echo e(asset('assets/images/arrow-right-red.svg')); ?>" height="36" alt="..." />
                    </a>
                </div>
                <div class="col-12 mb-3">
                    <a href="#" class="text-dark text-decoration-none d-flex justify-content-between align-items-center border bg-transparent py-2 px-3 rounded-lg">
                        <h5 class="mb-0">2018 Yıllık Raporu</h5>
                        <img  src="<?php echo e(asset('assets/images/arrow-right-red.svg')); ?>" height="36" alt="..." />
                    </a>
                </div>
                <div class="col-12 mb-3">
                    <a href="#" class="text-dark text-decoration-none d-flex justify-content-between align-items-center border bg-transparent py-2 px-3 rounded-lg">
                        <h5 class="mb-0">2017 Yıllık Raporu</h5>
                        <img  src="<?php echo e(asset('assets/images/arrow-right-red.svg')); ?>" height="36" alt="..." />
                    </a>
                </div>

            </div>
            <div class="row">
                <div class="col-12">
                    <h6 class="text-secondary">Quisque velit nisi, pretium ut lacinia in, elementum id enim</h6>
                    <a class="text-danger text-decoration-none font-weight-bold" href="#">www.turkishmetals.org</a>
                </div>
            </div>
        </div>
    </main>


 <?php if (isset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0)): ?>
<?php $component = $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0; ?>
<?php unset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\wamp64\www\iddmib\resources\views/frontend/raporlar.blade.php ENDPATH**/ ?>