 <?php if (isset($component)) { $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FrontApp::class, []); ?>
<?php $component->withName('front-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <main class="detail">
        <div class="position-relative mb-4">
            <img src="<?php echo e(asset('assets/images/aboutBg.png')); ?>" alt="" class="img-fluid" />
            <div class="container">
                <div class="bread"><h1 class="text-white">İletişim</h1></div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-wrap">
                    <h4>İDDMİB idari kadrosunu tanıyın!</h4>



                </div>
            </div>
        </div>
        <hr class="mb-5" />

        <div class="container mb-5">
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="text-danger font-weight-bold">Adres Bilgileri</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-sm-6">
                    <img src="<?php echo e(asset('assets/images/contact.svg')); ?>" alt="..." class="img-fluid" />
                </div>
                <div class="col-12 col-sm-6">
                    <h5>İstanbul Demir ve Demir Dışı Metaller İhracatçılar Birliği</h5>
                    <p>Sanayi Cad. No:3, Dış Ticaret Kompleksi
                        A Blok, Çobançeşme Mevkii 34196
                        Bahçelievler / İSTANBUL</p>
                    <p>
                        +90 (212) 454 00 00 (Pbx) <br />
                        iddmib@immib.org.tr
                    </p>
                    <a class="text-danger text-decoration-none font-weight-bold" href="#">Adrese Git</a>
                </div>
            </div>
        </div>
        <hr class="mb-5" />
        <form method="post" action="<?php echo e(route('iletisim_gonder')); ?>">
            <?php echo csrf_field(); ?>
        <div class="container py-5">
            <div class="row mb-4">
                <div class="col-12">
                    <h2 class="text-danger">İletişim ve Öneri Formu</h2>
                    <h4 class="text-secondary">Firma güvencesiyle!</h4>
                </div>
            </div>
            <div class="row mb-4">
                <div class="col-12">
                    <textarea required name="mesaj" class="form-control bg-transparent" rows="4" placeholder="İletişim Konusu"></textarea>
                </div>
            </div>
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="row mb-4">
                        <div class="col-12">
                          <input  type="text" name="isim_soyisim" class="form-control bg-transparent" placeholder="İsim Soyisim" />
                        </div>
                    </div>
                    <div class="row mb-4">
                        <div class="col-12">
                            <input required type="email" name="email" class="form-control bg-transparent" placeholder="E-Posta" />
                        </div>
                    </div>
                    <div class="row mb-4 mb-md-0">
                        <div class="col-12">
                            <input required type="tel" name="tel" class="form-control bg-transparent" placeholder="Telefon" />
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <textarea required name="adres" class="form-control h-100 bg-transparent"  placeholder="Adres"></textarea>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <button type="submit" class="btn btn-danger">GÖNDER</button>
                </div>
            </div>
        </div>
        </form>















































































































    </main>
 <?php if (isset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0)): ?>
<?php $component = $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0; ?>
<?php unset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\wamp64\www\iddmib\resources\views/frontend/iletisim.blade.php ENDPATH**/ ?>