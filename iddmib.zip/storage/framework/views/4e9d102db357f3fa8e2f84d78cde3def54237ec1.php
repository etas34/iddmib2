 <?php if (isset($component)) { $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FrontApp::class, []); ?>
<?php $component->withName('front-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>


    <main class="detail">
        <div class="position-relative mb-4">
            <img src="<?php echo e(asset('assets/images/aboutBg.png')); ?>" alt="" class="img-fluid"/>
            <div class="container">
                <div class="bread"><h1 class="text-white">İdari Kadro</h1></div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-wrap">
                    <h4>İDDMİB idari kadrosunu tanıyın!</h4>


                </div>
            </div>
        </div>
        <hr class="mb-5"/>

        <!-- sectors start -->
        <div class="sectors mb-5">
            <div class="container">
                <div class="row mb-4">
                    <div class="col-12">
                        <h3 class="text-danger font-weight-bold">Ekibimiz ve İletişim Bilgileri</h3>
                    </div>
                </div>
                <div class="row row-cols-sm-2 row-cols-md-3 text-center text-sm-left">

                    <?php $__currentLoopData = $kadro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($value->kadro ==  'İdari Kadro'): ?>
                            <div class="col-12 mb-3">
                                <a ><img class="img-fluid mb-3" src="<?php echo e(asset("storage/images/kadro_images/$value->resim")); ?>"
                                                 alt="..."/></a>
                                <h4><a class="text-dark font-weight-bold text-decoration-none"><?php echo e($value->ad_soyad); ?></a>
                                </h4>
                                <p><a class="text-secondary text-decoration-none">
                                        <?php if($value->sektor_id!=null): ?>
                                            <?php $__currentLoopData = explode(",",$value->sektor_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sektor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($sektor==999): ?>
                                                    Metaller Sektörü <br/>
                                                <?php else: ?>
                                                    <?php echo e(\App\Models\Sektor::find($sektor)->baslik); ?> Sektörü <br/>
                                                <?php endif; ?>


                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php echo e($value->unvan); ?>

                                <div class="w-100"></div>
                                <?php echo e($value->tel); ?> <br/>
                                <?php echo e($value->email); ?>

                                </p></a>
                            </div>
                        <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>

    </main>


 <?php if (isset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0)): ?>
<?php $component = $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0; ?>
<?php unset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\wamp64\www\iddmib\resources\views/frontend/idarikadro.blade.php ENDPATH**/ ?>