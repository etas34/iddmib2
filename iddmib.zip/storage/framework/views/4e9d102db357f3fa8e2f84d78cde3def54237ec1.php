 <?php if (isset($component)) { $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FrontApp::class, []); ?>
<?php $component->withName('front-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>


    <main class="detail">
        <div class="position-relative mb-4">
            <img  src="<?php echo e(asset('assets/images/aboutBg.png')); ?>" alt="" class="img-fluid" />
            <div class="container">
                <div class="bread"><h1 class="text-white">İdari Kadro</h1></div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-wrap">
                    <h4>Rum intio veribus core adis exerum, vel el mollabo...</h4>


                </div>
            </div>
        </div>
        <hr class="mb-5" />

        <!-- sectors start -->
        <div class="sectors mb-5">
            <div class="container">
                <div class="row mb-4">
                    <div class="col-12">
                        <h3 class="text-danger font-weight-bold">Ekibimiz ve İletişim Bilgileri</h3>
                    </div>
                </div>
                <div class="row row-cols-sm-2 row-cols-md-3 text-center text-sm-left">
                    <div class="col-12 mb-3">
                        <a href="#"><img class="img-fluid mb-3"  src="<?php echo e(asset('assets/images/profile1.svg')); ?>" alt="..." /></a>
                        <h4><a class="text-dark font-weight-bold text-decoration-none" href="#">Özgür İnan</a></h4>
                        <p><a class="text-secondary text-decoration-none" href="#">Metaller Sektör Şubesi <br />
                                Şube Müdür <div class="w-100"></div>
                        +90 212 454 0991 <br />
                        ozgur.inan@immib.org.tr
                        </a></p>
                    </div>
                    <div class="col-12 mb-3">
                        <a href="#"><img class="img-fluid mb-3"  src="<?php echo e(asset('assets/images/profile2.svg')); ?>" alt="..." /></a>
                        <h4><a class="text-dark font-weight-bold text-decoration-none" href="#">Özgür İnan</a></h4>
                        <p><a class="text-secondary text-decoration-none" href="#">Metaller Sektör Şubesi <br />
                                Şube Müdür <div class="w-100"></div>
                        +90 212 454 0991 <br />
                        ozgur.inan@immib.org.tr
                        </a></p>
                    </div>
                    <div class="col-12 mb-3">
                        <a href="#"><img class="img-fluid mb-3"  src="<?php echo e(asset('assets/images/profile3.svg')); ?>" alt="..." /></a>
                        <h4><a class="text-dark font-weight-bold text-decoration-none" href="#">Özgür İnan</a></h4>
                        <p><a class="text-secondary text-decoration-none" href="#">Metaller Sektör Şubesi <br />
                                Şube Müdür <div class="w-100"></div>
                        +90 212 454 0991 <br />
                        ozgur.inan@immib.org.tr
                        </a></p>
                    </div>
                    <div class="col-12 mb-3">
                        <a href="#"><img class="img-fluid mb-3"  src="<?php echo e(asset('assets/images/profile1.svg')); ?>" alt="..." /></a>
                        <h4><a class="text-dark font-weight-bold text-decoration-none" href="#">Özgür İnan</a></h4>
                        <p><a class="text-secondary text-decoration-none" href="#">Metaller Sektör Şubesi <br />
                                Şube Müdür <div class="w-100"></div>
                        +90 212 454 0991 <br />
                        ozgur.inan@immib.org.tr
                        </a></p>
                    </div>
                    <div class="col-12 mb-3">
                        <a href="#"><img class="img-fluid mb-3"  src="<?php echo e(asset('assets/images/profile2.svg')); ?>" alt="..." /></a>
                        <h4><a class="text-dark font-weight-bold text-decoration-none" href="#">Özgür İnan</a></h4>
                        <p><a class="text-secondary text-decoration-none" href="#">Metaller Sektör Şubesi <br />
                                Şube Müdür <div class="w-100"></div>
                        +90 212 454 0991 <br />
                        ozgur.inan@immib.org.tr
                        </a></p>
                    </div>
                    <div class="col-12 mb-3">
                        <a href="#"><img class="img-fluid mb-3"  src="<?php echo e(asset('assets/images/profile3.svg')); ?>" alt="..." /></a>
                        <h4><a class="text-dark font-weight-bold text-decoration-none" href="#">Özgür İnan</a></h4>
                        <p><a class="text-secondary text-decoration-none" href="#">Metaller Sektör Şubesi <br />
                                Şube Müdür <div class="w-100"></div>
                        +90 212 454 0991 <br />
                        ozgur.inan@immib.org.tr
                        </a></p>
                    </div>
                    <div class="col-12 mb-3">
                        <a href="#"><img class="img-fluid mb-3"  src="<?php echo e(asset('assets/images/profile1.svg')); ?>" alt="..." /></a>
                        <h4><a class="text-dark font-weight-bold text-decoration-none" href="#">Özgür İnan</a></h4>
                        <p><a class="text-secondary text-decoration-none" href="#">Metaller Sektör Şubesi <br />
                                Şube Müdür <div class="w-100"></div>
                        +90 212 454 0991 <br />
                        ozgur.inan@immib.org.tr
                        </a></p>
                    </div>
                    <div class="col-12 mb-3">
                        <a href="#"><img class="img-fluid mb-3"  src="<?php echo e(asset('assets/images/profile2.svg')); ?>" alt="..." /></a>
                        <h4><a class="text-dark font-weight-bold text-decoration-none" href="#">Özgür İnan</a></h4>
                        <p><a class="text-secondary text-decoration-none" href="#">Metaller Sektör Şubesi <br />
                                Şube Müdür <div class="w-100"></div>
                        +90 212 454 0991 <br />
                        ozgur.inan@immib.org.tr
                        </a></p>
                    </div>
                    <div class="col-12 mb-3">
                        <a href="#"><img class="img-fluid mb-3"  src="<?php echo e(asset('assets/images/profile3.svg')); ?>" alt="..." /></a>
                        <h4><a class="text-dark font-weight-bold text-decoration-none" href="#">Özgür İnan</a></h4>
                        <p><a class="text-secondary text-decoration-none" href="#">Metaller Sektör Şubesi <br />
                                Şube Müdür <div class="w-100"></div>
                        +90 212 454 0991 <br />
                        ozgur.inan@immib.org.tr
                        </a></p>
                    </div>


                </div>
            </div>
        </div>

    </main>



 <?php if (isset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0)): ?>
<?php $component = $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0; ?>
<?php unset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\wamp64\www\iddmib\resources\views/frontend/idarikadro.blade.php ENDPATH**/ ?>