 <?php if (isset($component)) { $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FrontApp::class, []); ?>
<?php $component->withName('front-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>



    <main class="detail">
        <div class="position-relative mb-4">
            <img  src="<?php echo e(asset('assets/images/aboutBg.png')); ?>" alt="" class="img-fluid" />
            <div class="container">
                <div class="bread"><h1 class="text-white">İhracat Radarı</h1></div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-wrap">
                    <h4><?php echo e($ir->altbaslik); ?></h4>


                </div>
            </div>
        </div>
        <hr class="mb-5" />

        <div class="container mb-5">
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="text-danger font-weight-bold"><?php echo e($ir->metinbaslik); ?>

                    </h3>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <img  src="<?php echo e(asset("storage/images/sayfalar_images/$ir->image")); ?>" alt="..." class="img-fluid mb-4" />

                    <?php echo $ir->metin; ?>



                    <a href="<?php echo e($ir->link); ?>" class="text-decoration-none text-light d-flex justify-content-between bg-red p-3 text-light w-100">
                        <div class="d-flex  align-items-center">

                            <h4 class="m-0">
                                <?php echo e($ir->link_baslik); ?> <br />
                                <?php echo e($ir->link_altbaslik); ?>

                            </h4>
                        </div>
                        <img  src="<?php echo e(asset('assets/images/arrow-right-light.svg')); ?>" width="46" alt="..." />
                    </a>
                </div>
            </div>
        </div>

    </main>


 <?php if (isset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0)): ?>
<?php $component = $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0; ?>
<?php unset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\wamp64\www\iddmib\resources\views/frontend/ihracatrota.blade.php ENDPATH**/ ?>