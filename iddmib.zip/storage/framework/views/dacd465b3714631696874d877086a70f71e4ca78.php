 <?php if (isset($component)) { $__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminApp::class, []); ?>
<?php $component->withName('admin-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('styles'); ?>


    <?php $__env->stopPush(); ?>


    <div class="row">
        <!-- left column -->
        <div class="col-md-12 form-group">
            <!-- general form elements -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Sektor Düzenle</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <form action="<?php echo e(route('admin.sektor.update',$sektor)); ?>" method="post" autocomplete="off"
                      enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="card-body">

                        <?php if($sektor->image): ?>
                            <div class="form-group">
                                <label for="file">Seçili resim:</label>
                                <div id="file"> <img src="<?php echo e(asset("storage/images/sektor_images/$sektor->image")); ?>" width="300"  alt="..."></div>
                            </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <label for="exampleInputFile">Sektör Resmi (350 X 233 )</label>
                            <div class="input-group">
                                <div class="custom-file">
                                    <input  type="file" name="image" class="custom-file-input" id="foto">
                                    <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                </div>

                            </div>
                            <span id="error_foto"></span>

                        </div>


                        <div class="row">
                            <div class="col-12">
                                <!-- Custom Tabs -->
                                <div class="card">
                                    <div class="card-header d-flex p-0">
                                        <h3 class="card-title p-3">Translate</h3>
                                        <ul class="nav nav-pills ml-auto p-2">
                                            <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="nav-item"><a class="nav-link <?php if($key == 'tr'): ?> active <?php endif; ?>"
                                                                        href="#<?php echo e($key); ?>"
                                                                        data-toggle="tab"><?php echo e($value); ?></a></li>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ul>
                                    </div><!-- /.card-header -->
                                    <div class="card-body">
                                        <div class="tab-content">
                                            <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="tab-pane <?php if($key == 'tr'): ?> active <?php endif; ?>" id="<?php echo e($key); ?>">

                                                    <div class="row">
                                                        <div class="col-md-6">
                                                        <label for="cat_name">Sektor Başlığı (<?php echo e($value); ?>)</label>
                                                        <input  type="text" name="baslik[<?php echo e($key); ?>]"
                                                               value=" <?php if(array_key_exists($key,$sektor->getTranslations('baslik'))): ?> <?php echo e($sektor->getTranslations('baslik')[$key]); ?> <?php endif; ?>"      class="form-control" id="cat_name">
                                                        </div>


                                                        <div class="col-md-6">
                                                        <label>Sektor Alt Başlık (<?php echo e($value); ?>)</label>
                                                        <input  name="alt_baslik[<?php echo e($key); ?>]" class="form-control" value=" <?php if(array_key_exists($key,$sektor->getTranslations('alt_baslik'))): ?> <?php echo e($sektor->getTranslations('alt_baslik')[$key]); ?> <?php endif; ?>"
                                                        >

                                                        </div>

                                                        <div class="col-md-12 form-group">
                                                        <label for="cat_name">Sektor Metin Başlığı (<?php echo e($value); ?>)</label>
                                                        <input  type="text" name="metin_baslik[<?php echo e($key); ?>]"
                                                               value=" <?php if(array_key_exists($key,$sektor->getTranslations('metin_baslik'))): ?> <?php echo e($sektor->getTranslations('metin_baslik')[$key]); ?> <?php endif; ?>"      class="form-control" id="cat_name">
                                                        </div>
                                                        <div class="col-md-12 form-group">

                                                        <label>Sektor İçeriği (<?php echo e($value); ?>)</label>
                                                        <textarea id="summernote_<?php echo e($key); ?>" name="aciklama[<?php echo e($key); ?>]"
                                                        >  <?php if(array_key_exists($key,$sektor->getTranslations('aciklama'))): ?> <?php echo e($sektor->getTranslations('aciklama')[$key]); ?> <?php endif; ?></textarea>

                                                    </div>
                                                        <div class="col-md-6">
                                                            <label>Sektor Link Başlık(<?php echo e($value); ?>)</label>
                                                            <input required name="sektor_link_baslik[<?php echo e($key); ?>]"
                                                                   class="form-control"
                                                                   value=" <?php if(array_key_exists($key,$sektor->getTranslations('sektor_link_baslik'))): ?> <?php echo e($sektor->getTranslations('sektor_link_baslik')[$key]); ?> <?php endif; ?>"
                                                            >
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label>Sektor Link Alt Başlık(<?php echo e($value); ?>)</label>
                                                            <input required name="sektor_link_altbaslik[<?php echo e($key); ?>]"
                                                                   class="form-control"
                                                                   value=" <?php if(array_key_exists($key,$sektor->getTranslations('sektor_link_altbaslik'))): ?> <?php echo e($sektor->getTranslations('sektor_link_altbaslik')[$key]); ?> <?php endif; ?>"

                                                            >
                                                        </div>
                                                    </div>

                                                    </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>
                                        <!-- /.tab-content -->
                                    </div><!-- /.card-body -->
                                </div>
                                <!-- ./card -->
                                <div class="card bg-light mb-3">
                                    <div class="card-header">
                                        <h4 > Sektör Bilgileri </h4>
                                    </div>
                                    <div class="card-body">


                                        <div class="row">

                                            <div class="col-md-12 form-group">
                                                <label for="exampleInputFile">Sektör Resmi (1920 X 1080 )</label>
                                                <div class="input-group">
                                                    <div class="custom-file">
                                                        <input  type="file" name="sektor_resim" class="custom-file-input" id="foto2" required>
                                                        <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                                    </div>

                                                </div>
                                                <span id="error_foto2"></span>
                                                <?php if($errors->any()): ?>
                                                    <div class="alert alert-danger">
                                                        <ul>
                                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li><?php echo e($error); ?></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <?php if($sektor->sektor_resim): ?>
                                            <div class="col-md-12 form-group">

                                                    <div class="form-group">
                                                        <label for="file">Seçili resim:</label>
                                                        <div id="file">
                                                            <img src="<?php echo e(asset("storage/images/sektor_resim/$sektor->sektor_resim")); ?>"
                                                                 width="300"
                                                                 alt="...">
                                                        </div>

                                                    </div>

                                            </div>
                                            <?php endif; ?>
                                            <div class="col-md-12 form-group">
                                                <label for="sktrlnk">Sektör Link</label>
                                                <input  type="text" value="<?php echo e($sektor->sektor_link); ?>" id="sktrlink" name="sektor_link" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card bg-light mb-3">
                                    <div class="card-header">
                                        <h4> Aliminyum GTİP Listesi ve Tanıtım </h4>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">


                                            <div class="form-group col-md-6">


                                                <label for="exampleInputFile">Sektör GTİP Listesi</label>
                                                <div class="input-group">
                                                    <div class="custom-file">
                                                        <input  type="file" name="gtip_pdf" accept="application/pdf"
                                                               class="custom-file-input"
                                                               id="foto">
                                                        <label class="custom-file-label" for="exampleInputFile">Choose
                                                            file</label>
                                                    </div>

                                                </div>
                                                <?php if($sektor->gtip_pdf): ?>
                                                    <div class="form-group">
                                                        <label>Seçili GTIP pdf:</label>
                                                        <div class="custom-file">
                                                            <a target="_blank"
                                                               href="<?php echo e(asset("storage/files/gtip_pdf/$sektor->gtip_pdf")); ?>"> <?php echo e($sektor->gtip_pdf); ?>

                                                                <i class="nav-icon fa fa-file-pdf"></i></a>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                            </div>
                                            <div class="form-group col-md-6">


                                                <label for="exampleInputFile">Sektör Tanıtım Broşürü</label>
                                                <div class="input-group">
                                                    <div class="custom-file">
                                                        <input  type="file"
                                                               name="tanitim_pdf"
                                                               accept="application/pdf"
                                                               class="custom-file-input"
                                                               id="foto">
                                                        <label class="custom-file-label" for="exampleInputFile">Choose
                                                            file</label>
                                                    </div>

                                                </div>
                                                <?php if($sektor->tanitim_pdf): ?>
                                                    <div class="form-group">
                                                        <label>Tanıtım PDF:</label>
                                                        <div class="custom-file">
                                                            <a target="_blank"
                                                               href="<?php echo e(asset("storage/files/tanitim_pdf/$sektor->tanitim_pdf")); ?>"> <?php echo e($sektor->tanitim_pdf); ?>

                                                                <i class="nav-icon fa fa-file-pdf"></i></a>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->



                    </div>
                    <!-- /.card-body -->

                    <div class="card-footer">
                        <button type="submit" id="edit" class="btn btn-primary float-right">Kaydet</button>
                    </div>
                </form>
            </div>
            <!-- /.card -->

        </div>
    </div>


    <?php $__env->startPush('scripts'); ?>
        <script>

            var _URL2 = window.URL || window.webkitURL;
            $("#foto").change(function (e) {
                var file, img;
                if ((file = this.files[0])) {
                    img = new Image();
                    var objectUrl = _URL2.createObjectURL(file);
                    img.onload = function () {

                        if (this.width != 350 && this.height != 233) {

                            $('#error_foto').html('<label class="text-danger">Lütfen 350 X 233 boyutlarında yükleyiniz</label>');
                            $('#foto').addClass('has-error');
                            $('#edit').attr('disabled', true);
                        } else {

                            $('#error_foto').html('<label class="text-success"></label>');
                            $('#foto').removeClass('has-error');
                            $('#edit').attr('disabled', false);

                        }


                        _URL2.revokeObjectURL(objectUrl);
                    };
                    img.src = objectUrl;
                }

            })

            var _URL3 = window.URL || window.webkitURL;
            $("#foto2").change(function (e) {
                var file, img;
                if ((file = this.files[0])) {
                    img = new Image();
                    var objectUrl = _URL3.createObjectURL(file);
                    img.onload = function () {

                        if (this.width != 1920 && this.height != 280) {

                            $('#error_foto2').html('<label class="text-danger">Lütfen 1920 X 1080 boyutlarında yükleyiniz</label>');
                            $('#foto2').addClass('has-error');
                            $('#edit2').attr('disabled', true);
                        } else {

                            $('#error_foto2').html('<label class="text-success"></label>');
                            $('#foto2').removeClass('has-error');
                            $('#edit').attr('disabled', false);

                        }


                        _URL2.revokeObjectURL(objectUrl);
                    };
                    img.src = objectUrl;
                }

            })

            $(function () {
                <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                $("#summernote_<?php echo e($key); ?>").summernote({
                    height: 300
                })
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            })


        </script>

    <?php $__env->stopPush(); ?>
 <?php if (isset($__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7)): ?>
<?php $component = $__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7; ?>
<?php unset($__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php /**PATH C:\wamp64\www\iddmib\resources\views/admin/sektor/edit.blade.php ENDPATH**/ ?>