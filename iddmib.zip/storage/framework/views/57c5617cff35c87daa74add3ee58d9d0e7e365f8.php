 <?php if (isset($component)) { $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FrontApp::class, []); ?>
<?php $component->withName('front-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <!-- header end -->

    <main class="detail">
        <div class="position-relative mb-4">
            <img src="<?php echo e(asset('assets/images/aboutBg.png')); ?>" alt="" class="img-fluid" />
            <div class="container">
                <div class="bread"><h1 class="text-white"><?php echo e($inovasyon->baslik); ?></h1></div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-wrap">
                    <h4><?php echo e($inovasyon->alt_baslik); ?></h4>
                </div>
            </div>
        </div>
        <hr class="mb-5" />

        <div class="container mb-5">

            <div class="row">
                <div class="col-12">
                    <img src="<?php echo e(asset("storage/images/inovasyon_images/$inovasyon->detay_resim")); ?>" width="100%" alt="..." class="img-fluid mb-4" />

                        <h3 class="text-danger font-weight-bold"><?php echo e($inovasyon->metin_baslik); ?></h3>

                        <?php echo $inovasyon->metin; ?>



                    <?php if($inovasyon->id!=9 && $inovasyon->id!=10 && $inovasyon->id!=5): ?>
                    <a target="_blank" href="<?php echo e($inovasyon->link); ?>" class="text-decoration-none text-light d-flex justify-content-between bg-red p-3 text-light w-100">
                        <div class="d-flex  align-items-center">

                            <h4 class="m-0">
                                <?php echo e($inovasyon->link_baslik); ?> <br />
                                <?php echo e($inovasyon->link_altbaslik); ?>

                            </h4>
                        </div>
                        <img src="<?php echo e(asset('assets/images/arrow-right-light.svg')); ?>" width="46" alt="..." />
                    </a>
                        <?php endif; ?>
                </div>
            </div>
        </div>

    </main>

 <?php if (isset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0)): ?>
<?php $component = $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0; ?>
<?php unset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\wamp64\www\iddmib\resources\views/frontend/inovasyon.blade.php ENDPATH**/ ?>