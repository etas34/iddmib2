 <?php if (isset($component)) { $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FrontApp::class, []); ?>
<?php $component->withName('front-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<main class="detail">
    <div class="position-relative mb-4">
        <img src="<?php echo e(asset('/assets/images/aboutBg.png')); ?>" alt="" class="img-fluid" />
        <div class="container">
            <div class="bread"><h1 class="text-white"><?php echo e($sektor->baslik); ?></h1></div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-12 d-flex flex-wrap">
                <h4><?php echo e($sektor->alt_baslik); ?></h4>





            </div>
        </div>
    </div>
    <hr class="mb-5" />

    <div class="container">
        <div class="row">
            <div class="col-12">
                <img  width="100%"  src="<?php echo e(asset("storage/images/sektor_images/$sektor->detay_resim")); ?>" alt="..." class="mb-4" />
                <h3 class="text-danger font-weight-bold mt-3"><?php echo e($sektor->metin_baslik); ?></h3>

                <div class="my-3">
                    <?php echo $sektor->aciklama; ?>

                </div>
            </div>
        </div>
    </div>

    <!-- numbers start -->
    <div class="numbers bg-red text-light py-5 mb-5">
        <div class="container">
            <div class="row text-center text-sm-left">
                <div class="col-12 col-sm-4 d-flex flex-column mb-3 mb-sm-0">
                    <h2>İhracat <br /> Rakamları</h2>
                    <div class="mt-auto">
                        <p>Son Güncelleme Tarihi</p>

                        <p><?php echo e($ihracatrakam->guncelleme_tarih ?? ''); ?></p>
                    </div>
                </div>
                <div class="col-12 col-sm-4 mb-3 mb-sm-0">
                    <h2>Son Ay</h2>
                    <p><?php echo e($ihracatrakam->o_birinci ?? ''); ?></p>
                    <h1 class="display-3 font-weight-bold"><?php echo e($ihracatrakam->o_ikinci ?? ''); ?></h1>
                    <h4><?php echo e($ihracatrakam->o_ucuncu ?? ''); ?></h4>
                </div>
                <div class="col-12 col-sm-4 mb-3 mb-sm-0">
                    <h2>Son 12 Ay</h2>
                    <p><?php echo e($ihracatrakam->s_birinci ?? ''); ?></p>
                    <h1 class="display-3 font-weight-bold"><?php echo e($ihracatrakam->s_ikinci ?? ''); ?></h1>
                    <h4><?php echo e($ihracatrakam->s_ucuncu ?? ''); ?></h4>
                </div>
            </div>
        </div>
    </div>
    <!-- numbers end -->

    <!-- threeslide start -->
    <div class="threeslide mb-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="text-danger font-weight-bold"><?php echo e($sektor->name); ?> Etkinlik Takvimi</h3>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-12">
                    <div class="swiper-container">
                        <div class="swiper-wrapper">

                            <?php $__currentLoopData = $etkinlik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <div class="card">
                                        <div class="card-header text-danger bg-transparent"><?php echo e(\DateTime::createFromFormat("Y-m-d", $value->tarih)->format("d/m/Y")); ?>-<?php echo e(\DateTime::createFromFormat("Y-m-d", $value->tarih2)->format("d/m/Y")); ?></div>
                                        <div class="card-body">
                                            <h5><?php echo e($value->baslik); ?></h5>
                                        </div>
                                        <div class="card-footer bg-transparent border-top-0">
                                            <?php echo e($value->alt_baslik); ?>

                                        </div>
                                        <div class="card-footer bg-transparent border-top-0 text-secondary d-flex justify-content-between">
                                            <span><?php echo e(\App\Models\Sektor::find($value->sektor_id)->baslik); ?></span>
                                            <span><?php echo e(config('constants.kategori.'.$value->kategori_id)); ?></span>
                                        </div>
                                    </div>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                    </div>
                    <div role="button" class="three-left d-none d-md-block"><img src="<?php echo e(asset('/assets/images/arrow-left-red.svg')); ?>" alt="..." /></div>
                    <div role="button" class="three-right d-none d-md-block"><img src="<?php echo e(asset('/assets/images/arrow-right-red.svg')); ?>" alt="..." /></div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <a class="text-danger"  href="<?php echo e(route('etkinlik')); ?>">Tüm etkinliklerini göster</a>
                </div>
            </div>
        </div>
    </div>
    <hr class="mb-5" />
    <!-- threeslide end -->
    <?php if($sektor->id!=5 && $sektor->id!=6 && $sektor->id!=8): ?>
    <div class="container mb-5">
        <div class="row">
            <div class="col-12">
                <div class="position-relative">
                    <a href="<?php echo e($sektor->sektor_link); ?>"><img src="<?php echo e(asset("storage/images/sektor_resim/$sektor->sektor_resim")); ?>" alt="..." class="img-fluid" /></a>
                    <a href="<?php echo e($sektor->sektor_link); ?>" class="text-decoration-none text-light d-flex justify-content-between bg-red position-absolute p-3 text-light w-100" style="bottom:0;">
                        <div class="d-flex  align-items-center">
                            <h4 class="m-0"><?php echo e($sektor->sektor_link_baslik); ?> <br />
                                <?php echo e($sektor->sektor_link_altbaslik); ?>

                            </h4>
                        </div>
                        <img src="<?php echo e(asset('/assets/images/arrow-right-light.svg')); ?>" width="46" alt="..." />
                    </a>
                </div>
            </div>
        </div>

    </div>

    <hr class="mb-5" />
    <?php endif; ?>

    <!-- threeslide start -->
    <div class="threeslide mb-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="text-danger font-weight-bold"><?php echo e($sektor->baslik); ?> İhracat Raporları</h3>
                </div>
            </div>
            <div class="row mb-3 reports">
                <div class="col-12">
                    <div class="swiper-container">



                        <div class="swiper-wrapper">
                        <?php $__currentLoopData = $ihracat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="swiper-slide">
                                <a href="<?php echo e(asset("storage/files/ihracat_files/$value->pdf")); ?>" class="card p-3 text-decoration-none rounded-lg">
                                    <h4 class="text-dark text-decoration-none"><?php echo e($value->baslik); ?> &nbsp;</h4>
                                    <h6 class="text-secondary text-decoration-none"><?php echo e($value->baslik); ?> <br /> İhracat Raporu</h6>
                                </a>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                    <div role="button" class="three-left d-none d-md-block"><img src="<?php echo e(asset('/assets/images/arrow-left-red.svg')); ?>" alt="..." /></div>
                    <div role="button" class="three-right d-none d-md-block"><img src="<?php echo e(asset('/assets/images/arrow-right-red.svg')); ?>" alt="..." /></div>
                </div>
            </div>
        </div>
    </div>
    <!-- threeslide end -->

    <hr class="mb-4" />

    <!-- news start -->
    <div class="news mb-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="text-danger font-weight-bold">Sektörel Haberler ve Duyurular</h3>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-12">
                    <div class="swiper-container">
                        <div class="swiper-wrapper">
                            <?php $__currentLoopData = $haber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="swiper-slide">
                                <a href="#"><img class="img-fluid mb-3" src="<?php echo e(asset("storage/images/haber_images/$value->ana_resim")); ?>" alt="..." /></a>
                                <h5 class="text-secondary"><a class="text-dark text-decoration-none" href="#"><?php echo e($value->created_at ?? ''); ?></a></h5>
                                <h5><a class="text-dark text-decoration-none" href="#"><?php echo e($value->baslik); ?></a></h5>
                            </div>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>

                    </div>
                    <div role="button" class="news-left d-none d-md-block"><img src="<?php echo e(asset('/assets/images/arrow-left-red.svg')); ?>" alt="..." /></div>
                    <div role="button" class="news-right d-none d-md-block"><img src="<?php echo e(asset('/assets/images/arrow-right-red.svg')); ?>" alt="..." /></div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                  <a class="text-danger">Tüm haberleri göster</a>
                </div>
            </div>
        </div>
    </div>
    <!-- news end -->

    <hr class="mb-5" />


































    <!-- sectors start -->
    <div class="sectors mb-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="text-danger font-weight-bold"><?php echo e($sektor->baslik); ?>  Sektörü Ekibimiz</h3>
                </div>
            </div>
            <div class="row row-cols-sm-2 row-cols-md-3 text-center text-sm-left">
            <?php $__currentLoopData = $kadro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <div class="col-12 mb-3">
                    <a href="#"><img class="img-fluid mb-3" src="<?php echo e(asset("storage/images/kadro_images/$value->resim")); ?>" alt="..." /></a>
                    <h4><a class="text-dark font-weight-bold text-decoration-none" href="#"><?php echo e($value->ad_soyad); ?></a></h4>
                    <p><a class="text-secondary text-decoration-none" href="#"><?php echo e($sektor->baslik); ?> Sektörü <br />
                            <?php echo e($value->unvan); ?>

                    <div class="w-100"></div>
                            <?php echo e($value->tel); ?> <br />


                       <?php echo e($value->email); ?>

                    </a></p>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

</main>
 <?php if (isset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0)): ?>
<?php $component = $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0; ?>
<?php unset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php /**PATH C:\wamp64\www\iddmib\resources\views/frontend/sektordetail.blade.php ENDPATH**/ ?>