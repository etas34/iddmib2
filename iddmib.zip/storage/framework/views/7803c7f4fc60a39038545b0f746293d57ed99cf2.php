 <?php if (isset($component)) { $__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminApp::class, []); ?>
<?php $component->withName('admin-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('styles'); ?>


    <?php $__env->stopPush(); ?>


    <div class="row">
        <!-- left column -->
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Hakkımızda</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <form action="<?php echo e(route('admin.sayfalar.hakkimizda.update',$hakkimizda)); ?>" method="post" autocomplete="off"
                      enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="card-body">

                        <?php if($hakkimizda->image): ?>
                            <div class="form-group">
                                <label for="file">Seçili resim:</label>
                                <div id="file"><img src="<?php echo e(asset("storage/images/sayfalar_images/$hakkimizda->image")); ?>"
                                                    width="300" alt="..."></div>
                            </div>
                        <?php endif; ?>

                        <div class="form-group">
                            <label for="exampleInputFile">Başlık Resmi (1200 X 470 )</label>
                            <div class="input-group">
                                <div class="custom-file">
                                    <input type="file" name="image" class="custom-file-input" id="foto">
                                    <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                </div>

                            </div>
                            <span id="error_foto"></span>

                        </div>


                        <div class="row">
                            <div class="col-12">
                                <!-- Custom Tabs -->
                                <div class="card">
                                    <div class="card-header d-flex p-0">
                                        <h3 class="card-title p-3">Translate</h3>
                                        <ul class="nav nav-pills ml-auto p-2">
                                            <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="nav-item"><a class="nav-link <?php if($key == 'tr'): ?> active <?php endif; ?>"
                                                                        href="#<?php echo e($key); ?>"
                                                                        data-toggle="tab"><?php echo e($value); ?></a></li>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ul>
                                    </div><!-- /.card-header -->
                                    <div class="card-body">
                                        <div class="tab-content">
                                            <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="tab-pane <?php if($key == 'tr'): ?> active <?php endif; ?>" id="<?php echo e($key); ?>">
                                                    <div class="form-group">

                                                        <label for="cat_name">Alt Başlık (<?php echo e($value); ?>)</label>
                                                        <input <?php if($key == 'tr'): ?> required <?php endif; ?> type="text" name="altbaslik[<?php echo e($key); ?>]"
                                                               value=" <?php if(array_key_exists($key,$hakkimizda->getTranslations('altbaslik'))): ?> <?php echo e($hakkimizda->getTranslations('altbaslik')[$key]); ?> <?php endif; ?>"
                                                               class="form-control" id="cat_name"
                                                               >
                                                    </div>
                                                    <div class="form-group">

                                                        <label for="cat_name">Metin Başlık (<?php echo e($value); ?>)</label>
                                                        <input <?php if($key == 'tr'): ?> required <?php endif; ?> type="text" name="metinbaslik[<?php echo e($key); ?>]"
                                                               value=" <?php if(array_key_exists($key,$hakkimizda->getTranslations('metinbaslik'))): ?> <?php echo e($hakkimizda->getTranslations('metinbaslik')[$key]); ?> <?php endif; ?>"
                                                               class="form-control"  >
                                                    </div>
                                                    <div class="form-group">

                                                        <label for="cat_name">Metin İçerik (<?php echo e($value); ?>)</label>
                                                        <textarea <?php if($key == 'tr'): ?> required <?php endif; ?> id="summernote_<?php echo e($key); ?>" name="metin[<?php echo e($key); ?>]">
                                                            <?php if(array_key_exists($key,$hakkimizda->getTranslations('metin'))): ?> <?php echo e($hakkimizda->getTranslations('metin')[$key]); ?> <?php endif; ?>
                                                        </textarea>
                                                    </div>








                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>
                                        <!-- /.tab-content -->
                                        <div class="row">


                                            <div class="form-group col-md-6">


                                                <label for="exampleInputFile">İDDMİB Hakkında Kanun</label>
                                                <div class="input-group">
                                                    <div class="custom-file">
                                                        <input  type="file" name="pdf1" accept="application/pdf"
                                                                class="custom-file-input">
                                                        <label class="custom-file-label" for="exampleInputFile">Choose
                                                            file</label>
                                                    </div>

                                                </div>
                                                <?php if($hakkimizda->pdf1): ?>
                                                    <div class="form-group">
                                                        <label>Seçili PDF:</label>
                                                        <div class="custom-file">
                                                            <a target="_blank"
                                                               href="<?php echo e(asset("storage/files/sayfalar_files/$hakkimizda->pdf1")); ?>">İDDMİB Hakkında Kanun
                                                                <i class="nav-icon fa fa-file-pdf"></i></a>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                            </div>
                                            <div class="form-group col-md-6">


                                                <label for="exampleInputFile">İDDMİB Hakkında Yönetmelik</label>
                                                <div class="input-group">
                                                    <div class="custom-file">
                                                        <input  type="file"
                                                                name="pdf2"
                                                                accept="application/pdf"
                                                                class="custom-file-input">
                                                        <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                                    </div>

                                                </div>
                                                <?php if($hakkimizda->pdf2): ?>
                                                    <div class="form-group">
                                                        <label>Seçili PDF:</label>
                                                        <div class="custom-file">
                                                            <a target="_blank"
                                                               href="<?php echo e(asset("storage/files/sayfalar_files/$hakkimizda->pdf2")); ?>"> İDDMİB Hakkında Yönetmelik
                                                                <i class="nav-icon fa fa-file-pdf"></i></a>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </div>

                                        </div>
                                    </div><!-- /.card-body -->
                                </div>
                                <!-- ./card -->
                            </div>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->



                    </div>
                    <!-- /.card-body -->

                    <div class="card-footer">
                        <button type="submit" id="edit" class="btn btn-primary float-right">Kaydet</button>
                    </div>
                </form>
            </div>
            <!-- /.card -->

        </div>
    </div>


    <?php $__env->startPush('scripts'); ?>
        <script>
            var _URL2 = window.URL || window.webkitURL;
            $("#foto").change(function (e) {
                var file, img;
                if ((file = this.files[0])) {
                    img = new Image();
                    var objectUrl = _URL2.createObjectURL(file);
                    img.onload = function () {

                        if (this.width != 1920 && this.height != 900) {

                            $('#error_foto').html('<label class="text-danger">Lütfen 1920 X 900 boyutlarında yükleyiniz</label>');
                            $('#foto').addClass('has-error');
                            $('#edit').attr('disabled', true);
                        } else {

                            $('#error_foto').html('<label class="text-success"></label>');
                            $('#foto').removeClass('has-error');
                            $('#edit').attr('disabled', false);

                        }


                        _URL2.revokeObjectURL(objectUrl);
                    };
                    img.src = objectUrl;
                }

            })
            $(function () {
                <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                $("#summernote_<?php echo e($key); ?>").summernote({
                    height: 300
                })
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            })

        </script>

    <?php $__env->stopPush(); ?>
 <?php if (isset($__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7)): ?>
<?php $component = $__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7; ?>
<?php unset($__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php /**PATH C:\wamp64\www\iddmib\resources\views/admin/sayfalar/hakkimizda.blade.php ENDPATH**/ ?>