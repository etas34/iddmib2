 <?php if (isset($component)) { $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FrontApp::class, []); ?>
<?php $component->withName('front-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>


    <main class="detail">
        <div class="position-relative mb-4">
            <img src="<?php echo e(asset('assets/images/aboutBg.png')); ?>" alt="" class="img-fluid" />
            <div class="container">
                <div class="bread"><h1 class="text-white"><?php echo e($faaliyet->baslik); ?></h1></div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-wrap">
                    <h4><?php echo e($faaliyet->alt_baslik); ?></h4>





                </div>
            </div>
        </div>
        <hr class="mb-5" />

        <div class="container mb-5">
            <div class="row">
                <div class="col-12">
                    <img src="<?php echo e(asset("storage/images/faliyet_images/$faaliyet->detay_resim")); ?>"  width="100%" alt="..." class="img-fluid mb-4" />
                    <h3 class="text-danger font-weight-bold"><?php echo e($faaliyet->metin_baslik); ?></h3>
                    <?php echo $faaliyet->aciklama; ?>


                    <?php if(in_array('0',explode(',',$faaliyet->kategori_id))): ?>

                        <?php for($i = 1 ; $i <= 6 ; $i++ ): ?>
                    <a target="_blank" href="<?php echo e(unserialize($faaliyet->link)[$i]); ?>" class="text-decoration-none text-light d-flex justify-content-between bg-red p-3 mt-3 text-light w-100">
                        <div class="d-flex  align-items-center">
                            <img src="<?php echo e(asset('assets/images/doc-light.svg')); ?>" class="mr-3" width="46" alt="..." />
                            <h4 class="m-0">
                                <?php echo e(unserialize($faaliyet->link_baslik)[$i]); ?> <br />
                                <?php echo e(unserialize($faaliyet->link_altbaslik)[$i]); ?>

                            </h4>
                        </div>

                        <img src="<?php echo e(asset('assets/images/arrow-right-light.svg')); ?>" width="46" alt="..." />
                    </a>
                        <?php endfor; ?>

                    <?php endif; ?>

                </div>
            </div>
        </div>
<?php if(!in_array('0',explode(',',$faaliyet->kategori_id))): ?>



        <!-- threeslide start -->
        <div class="threeslide mb-5">
            <div class="container">
                <div class="row mb-3">
                    <div class="col-12">
                        <div class="swiper-container">
                            <div class="swiper-wrapper">
                             <?php $__currentLoopData = $etkinlik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <div class="card">
                                        <div class="card-header text-danger bg-transparent"><?php echo e($value->tarih); ?></div>
                                        <div class="card-body">
                                            <?php echo e($value->baslik); ?>

                                        </div>
                                        <div class="card-footer bg-transparent border-top-0">
                                            <?php echo e($value->alt_baslik); ?>

                                        </div>

                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </div>

                        </div>
                        <div role="button" class="three-left d-none d-md-block"><img src="<?php echo e(asset('assets/images/arrow-left-red.svg')); ?>" alt="..." /></div>
                        <div role="button" class="three-right d-none d-md-block"><img src="<?php echo e(asset('assets/images/arrow-right-red.svg')); ?>" alt="..." /></div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                      <a class="text-danger">Tüm Milli Katılım Organizasyonlarını Göster</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- threeslide end -->
    <?php endif; ?>


    </main>

 <?php if (isset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0)): ?>
<?php $component = $__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0; ?>
<?php unset($__componentOriginal931043470edf29675fbf7964dddcc743a9f7fec0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\wamp64\www\iddmib\resources\views/frontend/faaliyet.blade.php ENDPATH**/ ?>