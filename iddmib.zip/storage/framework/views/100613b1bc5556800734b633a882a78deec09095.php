 <?php if (isset($component)) { $__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminApp::class, []); ?>
<?php $component->withName('admin-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('styles'); ?>


    <?php $__env->stopPush(); ?>


    <div class="row">
        <!-- left column -->
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">Kadrolar</h2>
                    <a href="<?php echo e(route('admin.sayfalar.kadro_create')); ?>" class="btn btn-primary active"
                       style="float: right !important;">Yeni Kadro Ekle</a>
                </div>
                <!-- /.card-header -->
                <div class="card-body py-2">
                    <h2 class="card-title">Yönetim Kurulu</h2>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>Resim</th>
                            <th>Kadro</th>
                            <th>Ünvan</th>
                            <th>Ad Soyad</th>
                            <th>Telefon Numarası</th>
                            <th>E-Mail</th>
                            <th>Sıra</th>


                            
                            <th>Düzenle</th>
                            <th>Sil</th>


                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $kadro_yonetim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><img src="<?php echo e(asset("storage/images/kadro_images/$value->resim")); ?>" height="60px"
                                         width="60px"></td>
                                <td> <?php echo e($value->kadro); ?></td>
                                <td> <?php echo e($value->unvan); ?></td>
                                <td> <?php echo e($value->ad_soyad); ?></td>
                                <td> <?php echo e($value->tel); ?></td>
                                <td> <?php echo e($value->email); ?></td>
                                <td>
                                    <form action="<?php echo e(route('admin.sayfalar.kadro_sira',$value)); ?>" method="post" autocomplete="off">
                                        <?php echo e(csrf_field()); ?>

                                    <div class="input-group input-group-sm">
                                        <input type="text" class="text-center" name="sira" style="width: 50px;"
                                               value="<?php echo e($value->sira); ?>">
                                        <span class="input-group-append">
                    <button type="submit" class="btn btn-info btn-flat"><i class="fa fa-check"
                                                                           aria-hidden="true"></i></button>
                  </span>
                                    </div>
                                    </form>

                                </td>

                                <td><a href="<?php echo e(route('admin.sayfalar.kadro_edit',$value)); ?>"><span
                                            class="badge bg-warning p-2">Düzenle</span></a>
                                </td>
                                <td><a href="<?php echo e(route('admin.sayfalar.kadro_destroy',$value)); ?>"
                                       onclick="return confirm('Kaydı silmek istediğinize emin misiniz?')"><span
                                            class="badge bg-danger p-2">Sil</span></a></td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    </table>
                </div>
                <hr>
                <div class="card-body py-2">
                    <h2 class="card-title">Denetim Kurulu</h2>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>Resim</th>
                            <th>Kadro</th>
                            <th>Ünvan</th>
                            <th>Ad Soyad</th>
                            <th>Telefon Numarası</th>
                            <th>E-Mail</th>
                            <th>Sıra</th>


                            
                            <th>Düzenle</th>
                            <th>Sil</th>


                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $kadro_denetim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><img src="<?php echo e(asset("storage/images/kadro_images/$value->resim")); ?>" height="60px"
                                         width="60px"></td>
                                <td> <?php echo e($value->kadro); ?></td>
                                <td> <?php echo e($value->unvan); ?></td>
                                <td> <?php echo e($value->ad_soyad); ?></td>
                                <td> <?php echo e($value->tel); ?></td>
                                <td> <?php echo e($value->email); ?></td>
                                <td>
                                    <form action="<?php echo e(route('admin.sayfalar.kadro_sira',$value)); ?>" method="post" autocomplete="off">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="input-group input-group-sm">
                                            <input type="text" class="text-center" name="sira" style="width: 50px;"
                                                   value="<?php echo e($value->sira); ?>">
                                            <span class="input-group-append">
                    <button type="submit" class="btn btn-info btn-flat"><i class="fa fa-check"
                                                                           aria-hidden="true"></i></button>
                  </span>
                                        </div>
                                    </form>

                                </td>

                                <td><a href="<?php echo e(route('admin.sayfalar.kadro_edit',$value)); ?>"><span
                                            class="badge bg-warning p-2">Düzenle</span></a>
                                </td>
                                <td><a href="<?php echo e(route('admin.sayfalar.kadro_destroy',$value)); ?>"
                                       onclick="return confirm('Kaydı silmek istediğinize emin misiniz?')"><span
                                            class="badge bg-danger p-2">Sil</span></a></td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    </table>
                </div>
                <hr>
                <!-- /.card-body -->
                <div class="card-body py-2">
                    <h2 class="card-title">İdari Kadro</h2>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>Resim</th>
                            <th>Kadro</th>
                            <th>Sektör</th>
                            <th>Ünvan</th>
                            <th>Ad Soyad</th>
                            <th>Telefon Numarası</th>
                            <th>E-Mail</th>
                            <th>Sıra</th>


                            
                            <th>Düzenle</th>
                            <th>Sil</th>


                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $kadro_idari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><img src="<?php echo e(asset("storage/images/kadro_images/$value->resim")); ?>" height="60px"
                                         width="60px"></td>
                                <td> <?php echo e($value->kadro); ?></td>
                                <td><?php $__currentLoopData = explode(",",$value->sektor_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sektor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($sektor==999): ?>
                                            Metaller<br>
                                        <?php else: ?>
                                            <?php echo e(\App\Models\Sektor::find($sektor)->baslik ?? ''); ?><br>
                                        <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </td>
                                <td> <?php echo e($value->unvan); ?></td>
                                <td> <?php echo e($value->ad_soyad); ?></td>
                                <td> <?php echo e($value->tel); ?></td>
                                <td> <?php echo e($value->email); ?></td>
                                <td>
                                    <form action="<?php echo e(route('admin.sayfalar.kadro_sira',$value)); ?>" method="post" autocomplete="off">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="input-group input-group-sm">
                                            <input type="text" class="text-center" name="sira" style="width: 50px;"
                                                   value="<?php echo e($value->sira); ?>">
                                            <span class="input-group-append">
                    <button type="submit" class="btn btn-info btn-flat"><i class="fa fa-check"
                                                                           aria-hidden="true"></i></button>
                  </span>
                                        </div>
                                    </form>

                                </td>

                                <td><a href="<?php echo e(route('admin.sayfalar.kadro_edit2',$value)); ?>"><span
                                            class="badge bg-warning p-2">Düzenle</span></a>
                                </td>
                                <td><a href="<?php echo e(route('admin.sayfalar.kadro_destroy',$value)); ?>"
                                       onclick="return confirm('Kaydı silmek istediğinize emin misiniz?')"><span
                                            class="badge bg-danger p-2">Sil</span></a></td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    </table>
                </div>
            </div>
        </div>
    </div>


    <?php $__env->startPush('scripts'); ?>


    <?php $__env->stopPush(); ?>
 <?php if (isset($__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7)): ?>
<?php $component = $__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7; ?>
<?php unset($__componentOriginal8ccf4fb5701581142b90c3e2100c63584b8a65d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php /**PATH C:\wamp64\www\iddmib\resources\views/admin/sayfalar/kadro/index.blade.php ENDPATH**/ ?>