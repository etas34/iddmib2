<h2>Merhaba IDDMIB, </h2> <br><br>

{{ $email }} kişisinden E-posta aldınız,  <br><br>

Kullanıcı Bilgileri <br><br>

İsim Soyisim: {{ $isim_soyisim }} <br>
E-posta: {{ $email }} <br>
Telefon Numarası: {{ $tel }} <br>
Adres: {{ $adres }} <br><br>
Mesaj: {{ $mesaj }} <br>
