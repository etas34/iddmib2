<?php

return [

    'title' => 'This is English Language Title.',

];
